
That is a very reduced implementation of KDC using the KRB5 protocol,
it should not be used in production.

How to use it?
--------------

This application is all written in Python and does not demand installation
not compilation. It can be executed in the source folder by the utilization
of the `kdc-server.py' script.

The `kdc-server.py' script accept as parameters a set of options, those
options are listed below:

```
Usage: kdc-server.py [options]

Options:
  -h, --help            show this help message and exit
  -l 0.0.0.0, --listen=0.0.0.0
                        IP address to listen to, default: 0.0.0.0
  -p NUM, --port=NUM    TCP port to listen to, default: 88
  -d NUM, --debug=NUM   Debug level, 8 - network, 7 - protocol, all way to 0.
  -r REALM, --realm=REALM
                        Server realm, default: krb.crypto.biu.ac.il
  -u FILE, --users=FILE
                        Users database users.txt

```

Despite to the fact that the application is now understanding different users
during the initialization, the protocol side is not really supporting it, thus,
keep testing with user:password otherwise you may face conditionals errors that
are not treated yet.

Make sure you have the custom version of the kdcinit otherwise you won't be
able to get anything encrypted from this kdc implementation. This implementation
does not talk the default algos supported by the kdcinit

The krb configuration can be the exactly the same that we have used in the last
test. No need to change anything. Notice that you have to specify the realm
as the command line option, otherwise it will keep saying that your user is not
valid.


Python dependencies
-------------------

You may need to install extra Python dependencies in order to have the KDC
server running, the full list is available here:

 - Crypto
 - csv
 - datetime
 - hexdump
 - inspect
 - socket
 - struct
 - sys
 - thread
 - timea
 - dateutil
 - fractions

Most of those dependencies are installed by default. If you don't have one of those
dependencies Python will complain about it, during the execution of the kdc-server.


Next steps
----------

 [ ] Make encrypted part of the as-res full compatible with the request
 [ ] Make it work independent of the user name
 [ ] Create a dummy script to simulate the MPC
 [ ] Make this implementation to connect to the MPC via socket.


Related Projects
----------------

 - https://github.com/mhorowitz/pykrb5.git
 - https://github.com/greghudson/pyk5
