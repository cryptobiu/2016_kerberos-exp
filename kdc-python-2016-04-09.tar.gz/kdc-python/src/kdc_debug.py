
import hexdump
import time
import inspect


# caller_name from:
# http://stackoverflow.com/questions/2654113/python-how-to-get-the-callers-method-name-in-the-called-method
def caller_name(skip=2):
    """Get a name of a caller in the format module.class.method

       `skip` specifies how many levels of stack to skip while getting caller
       name. skip=1 means "who calls me", skip=2 "who calls my caller" etc.

       An empty string is returned if skipped levels exceed stack height
    """
    stack = inspect.stack()
    start = 0 + skip
    if len(stack) < start + 1:
      return ''
    parentframe = stack[start][0]    

    name = []
    module = inspect.getmodule(parentframe)
    # `modname` can be None when frame is executed directly in console
    # TODO(techtonik): consider using __main__
    if module:
        name.append(module.__name__)
    # detect classname
    if 'self' in parentframe.f_locals:
        # I don't know any way to detect call from the object method
        # XXX: there seems to be no way to detect static method call - it will
        #      be just a function call
        name.append(parentframe.f_locals['self'].__class__.__name__)
    codename = parentframe.f_code.co_name
    if codename != '<module>':  # top level usually
        name.append( codename ) # function or a method
    del parentframe
    return ".".join(name)


class KdcDebug(object):
    """
    8 - socket level.
    7 - protocol level.
    """
    _instance = None
    m_level = 0

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(KdcDebug, cls).__new__(
                                cls, *args, **kwargs)
        return cls._instance


    def __t(self):
        return time.strftime("[%H:%M:%S]")


    def setDebugLevel(self, level):
        self.m_level = level


    def debug(self, level, cn, msg):
        if (level <= self.m_level):
            print self.__t() + " " + cn + " - " + str(msg)
        return True


    def debug_hex(self, level, cn, msg):
        if (level <= self.m_level):
            print self.__t() + " --> (from: " + cn + ")"
            hexdump.hexdump(msg)
            print self.__t() + " <-- eot"
        return True


def kdcd(level, msg):
    return KdcDebug().debug(level, caller_name(), msg)


def kdcdh(level, msg):
    return KdcDebug().debug_hex(level, caller_name(), msg)

