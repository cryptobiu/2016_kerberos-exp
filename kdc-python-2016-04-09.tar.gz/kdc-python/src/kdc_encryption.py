

from Crypto.Cipher import AES
from Crypto.Util import Counter


def kdc_enc(tpe, key, plain):
    # 0x14 = ctr-aes.
    if tpe != 0x14:
        raise ValueError('I don\'t know how to cipher using: ' + str(tpe))

    nonce = "0000000000000000".decode('hex')
    c = Counter.new(64, initial_value=0, prefix=nonce)
    e = AES.new(key, mode=AES.MODE_CTR, counter = c)

    z = ""
    for i in plain:
        z = z + chr(i)

    edata = e.encrypt(z)

    return edata

