
from kdc_debug import *
from krb_request import *

SOCKET_BUFFER = 2048

class KdcConnection(object):
    def __init__(self, server, client_sock, addr):
        self.m_server = server
        self.m_client_sock = client_sock
        self.m_addr = addr


    def loop(self):
        while True:
            # There is no reason to be more complicated. 
            # The packages are usually very small, if better threatment
            # is needed it will be clear during the tests.
            data = self.m_client_sock.recv(SOCKET_BUFFER)
            if not data:
                kdcd(8, "Nothing to read, lets break.")
                self.close()
                break

            kdcd(8, "Request content:")
            kdcdh(8, data)
            krbObj = krb_request_from_data(data)
            kdcd(7, "Request type: " + str(KrbRequest.type2label(krbObj.m_type)))
            self.m_server.reply(self, krbObj)


    def send(self, data):
        kdcd(7, "Sending data:")
        kdcdh(7, data)
        self.m_client_sock.sendall(data)


    def close(self):
        kdcd(8, "Closed socket: `%s'" % self.m_client_sock)
        self.m_client_sock.close()


def kdc_request_handler(server, client_sock, addr):
    kdcd(8, "New request from: `%s'" % client_sock)
    connection = KdcConnection(server, client_sock, addr)
    connection.loop()

