
from kdc_socket import KdcSocket
from kdc_request_handler import kdc_request_handler
from krb_request import KrbRequest
from kdc_debug import *
from krb_error import *
from krb_response import *
from kdc_user import *

class KdcServer(object):
    def __init__(self, addr, port, realm):
        self.m_realm = []
        self.m_realm.append(realm)
        self.m_realm.append(realm.upper())
        self.m_realm.append(realm.lower())
        self.m_port = port
        self.m_addr = addr
        self.m_kdcSocket = KdcSocket(addr = addr, port = port)


    def handler(self, client_sock, addr):
        return kdc_request_handler(self, client_sock, addr)


    def listen(self):
        self.m_kdcSocket.listen()
        self.m_kdcSocket.loop(self.handler)


    def reply(self, connection, request):
        if request.m_type == KrbRequest.AS_REQ:
            if request.getRealm() not in self.m_realm:
                print "----------------------------"
                print request.getRealm()
                print str(self.m_realm)
                err = KrbErrorUnkPrinpical()
                connection.send(err.byts())
                return;
             
            try:
                user = request.getUser()
            except:
                err = KrbErrorUnkPrinpical()
                connection.send(err.byts())
                return;

            asResp = KrbResponseAsRep(user)
            connection.send(asResp.byts())

        err = KrbErroNoEtype()
        connection.send(err.byts())
