
import socket
import sys
import thread
from kdc_debug import *

class KdcSocket(object):

    m_sock = None
    m_addr = None
    m_port = 0


    def __init__(self, addr = "0.0.0.0", port = 88):
        self.m_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.m_addr = addr
        self.m_port = port


    def listen(self):
        saddr = (self.m_addr, self.m_port)
        self.m_sock.bind(saddr)
        self.m_sock.listen(1)
        kdcd(8, "Listening at: " + str(saddr))


    def loop(self, handler):
        while True:
            client_sock, client_addr = self.m_sock.accept()
            thread.start_new_thread(handler, (client_sock, client_addr))


