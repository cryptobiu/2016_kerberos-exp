
import csv
from kdc_debug import *
from kdc_crypto import *

class KdcUsersDataBase(object):
    _instance = None

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(KdcUsersDataBase, cls).__new__(
                                cls, *args, **kwargs)
        return cls._instance

    def init(self, db_file):
        self.m_db_file = db_file
        self.m_db = {}
        with open(self.m_db_file, 'rb') as csvfile:
            sr = csv.reader(csvfile, delimiter=",", quotechar='"')
            for row in sr:
                user = str(row[0])
                password = str(row[1])
                self.m_db[user] = password
        kdcd(6, "Loading users:")
        kdcd(6, str(self.m_db))

    def getUser(self, name):
        try:
            return KdcUser(name, self.m_db[name])
        except:
            raise ValueError('User not know')


class KdcUser(object):
    def __init__(self, name, password):
        self.m_name = name
        self.m_password = password

    def getKey(self):
        # we only support one algo, so that will be easy.
        return string2password(self.m_password)

    

