
import struct
from dateutil.relativedelta import relativedelta
import datetime
import hexdump
import kdc_response_example as KdcResponseExample
from kdc_encryption import *

class KrbResponse(object):
    def _write_date_time(self, date):
        a = datetime.datetime.now().__format__("%Y%m%d%H%M%SZ")
        self.m_buffer = self.m_buffer + a


    def _write_offset(self, size = 4):
        s = 0
        while s < size:
            self.m_buffer.append(0x00)
            s = s + 1


    def _write_integer(self, number, size = 4):
        b = struct.pack('>I', number)
        if size < 4:
            b = b[4-size:]
        self.m_buffer = self.m_buffer + b


    def _write_string(self, bts):
        self._write_bytes([0x1b])
        self._write_integer(len(bts), size = 1)
        self.m_buffer = self.m_buffer + bts


    def _write_bytes(self, byts):
        if isinstance(byts, list):
            for i in byts:
                self.m_buffer = self.m_buffer + chr(i)
        else:
            self.m_buffer = self.m_buffer + str(byts)


class KrbResponseAsRep(KrbResponse):

    RECORD_MARK = [0x00, 0x00, 0x02, 0xc3]
    INDICATOR = [0x6b, 0x82, 0x02, 0xbf, 0x30, 0x82, 0x02, 0xbb]
    PVNO = [0xa0, 0x03, 0x02, 0x01]
    MSG_TYPE = [0xa1, 0x03, 0x02, 0x01]
    PA_DATA = [0xa2, 0x2e, 0x30, 0x2c]
    CREALM = [0xa3, 0x12]
    CNAME = [0xa4, 0x11, 0x30, 0x0f]
    CNAME_NAME_TYPE = [0xa0, 0x03, 0x02, 0x01]
    CNAME_NAME_STRING = [0xa1, 0x08, 0x30, 0x06]
    TICKET = [0x30, 0x82, 0x01, 0x36]
    TICKET_VNO = [0xa0, 0x03, 0x02, 0x01]
    TICKET_REALM = [0xa1, 0x12]
    TICKET_SNAME = [0xa2, 0x25]
    TICKET_SNAME_NAME_TYPE = [0xa0, 0x03, 0x02, 0x01]
    TICKET_SNAME_NAME_STRING = [0xa1, 0x1c, 0x30, 0x1a]
    ENC_PART = [0xa6, 0x82, 0x01, 0x14]
    ENC_PART_ENC_TYPE = [0xa0, 0x03, 0x02, 0x01]
    ENC_ENC_BLOB = [0xa2, 0x82, 0x01, 0x07]

    def __init__(self, user):
        self.m_pvno = 5
        # kdc-as-resp
        self.m_msg_type = 0x0b
        self.m_byts = ""
        self.m_user = user

    def byts(self):
        # Cleanup
        self.m_buffer = ""

        # Record Mark.
        self._write_bytes(KrbResponseAsRep.RECORD_MARK)
        # indicator
        self._write_bytes(KrbResponseAsRep.INDICATOR)

        # pvno
        self._write_bytes(KrbResponseAsRep.PVNO)
        self._write_integer(self.m_pvno, 1)

        # msg type
        self._write_bytes(KrbResponseAsRep.MSG_TYPE)
        self._write_integer(self.m_msg_type, 1)

        # pa data
        self._write_bytes(KrbResponseAsRep.PA_DATA)

        # enc data, lets not touch this right now.
        # TODO: replace me with something that really works.
        self._write_bytes(KdcResponseExample.KDC_TICKET_ENC_DATA)

        # pa data
        self._write_bytes(KrbResponseAsRep.CREALM)
        self._write_string("KRB.ZIMMERLE.ORG")

        # cname
        self._write_bytes(KrbResponseAsRep.CNAME)
        # cname > name type
        self._write_bytes(KrbResponseAsRep.CNAME_NAME_TYPE)
        self._write_integer(0x01, 1)
        # cname > name string
        self._write_bytes(KrbResponseAsRep.CNAME_NAME_STRING)
        self._write_string("user")

        # Not sure what it is about.
        self._write_bytes([0xa5, 0x82, 0x01, 0x3e, 0x61, 0x82, 0x01, 0x3a])

        # ticket
        self._write_bytes(KrbResponseAsRep.TICKET)
        # ticket > vno
        self._write_bytes(KrbResponseAsRep.TICKET_VNO)
        self._write_integer(0x05, 1)
        # ticket > realm
        self._write_bytes(KrbResponseAsRep.TICKET_REALM)
        self._write_string("KRB.ZIMMERLE.ORG")
        # ticket > sname
        self._write_bytes(KrbResponseAsRep.TICKET_SNAME)
        # ticket > sname > not sure what it is.
        self._write_bytes([0x30, 0x23])
        # ticket > sname > name type
        self._write_bytes(KrbResponseAsRep.TICKET_SNAME_NAME_TYPE)
        self._write_integer(0x02, 1)
        # ticket > sname > strings
        self._write_bytes(KrbResponseAsRep.TICKET_SNAME_NAME_STRING)
        self._write_string("krbtgt")
        self._write_string("KRB.ZIMMERLE.ORG")
        # ticket > enc part
        # enc block. We can ignore this one.
        self._write_bytes(KdcResponseExample.KDC_TICKET_ENC_PART)

        # enc part
        self._write_bytes(KrbResponseAsRep.ENC_PART)
        # enc part > don't know what is it.
        self._write_bytes([0x30, 0x82, 0x01, 0x10])
        # enc part > enc type
        self._write_bytes(KrbResponseAsRep.ENC_PART_ENC_TYPE)
        self._write_integer(0x14, 1)

        # enc blob.
        self._write_bytes(KrbResponseAsRep.ENC_ENC_BLOB)
        self._write_bytes([0x04, 0x82]) # something.
        self._write_bytes([0x01, 0x03]) # size of the blob.

        # Lets try to perform the encryption
        a = kdc_enc(0x14, self.m_user.getKey(), KdcResponseExample.TGT_NOT_CIPHERED)

        # This is the block that we want to change.
        self._write_bytes(a)
        self._write_bytes([0x59, 0xb5, 0x5b, 0xaa, 0xc8, 0x98, 0x31, 0x3c, 0x02, 0x4c, 0xf1, 0x02])

        return self.m_buffer

