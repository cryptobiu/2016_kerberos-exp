#!/usr/bin/python


from optparse import OptionParser
import sys
sys.path.append("src");


from kdc_server import KdcServer
from kdc_debug import *


DEFAULT_DEBUG_LEVEL = 0
DEFAULT_LISTEN_PORT = 88
DEFAULT_LISTEN_IP = "0.0.0.0"
REALM = "krb.crypto.biu.ac.il"
USERS_DATABASE = "users.txt"



def main():
    parser = OptionParser()
    parser.add_option("-l", "--listen", dest="listen",
            help="IP address to listen to, default: " + str(DEFAULT_LISTEN_IP),
            metavar="0.0.0.0", default=DEFAULT_LISTEN_IP)

    parser.add_option("-p", "--port", dest="port",
            help="TCP port to listen to, default: " + str(DEFAULT_LISTEN_PORT),
            metavar="NUM", default=DEFAULT_LISTEN_PORT)

    parser.add_option("-d", "--debug", dest="debug",
            help="Debug level, 8 - network, 7 - protocol, all way to 0.",
            metavar="NUM", default=DEFAULT_DEBUG_LEVEL)

    parser.add_option("-r", "--realm", dest="realm",
            help="Server realm, default: " + REALM,
            metavar="REALM", default=REALM)

    parser.add_option("-u", "--users", dest="users",
            help="Users database " + USERS_DATABASE,
            metavar="FILE", default=USERS_DATABASE)


    (options, args) = parser.parse_args()


    print "Runing kdc-server at " + str(options.listen) + ":" \
            + str(options.port) + ""
    print "Debug level set to: " + str(options.debug) + ""
    print "Realm: " + str(options.realm) + ""
    print "User database: " + str(options.users)

    KdcDebug().setDebugLevel(options.debug)
    server = KdcServer(addr = options.listen,
            port = options.port, realm = options.realm)

    server.listen()

    #kdcSocket = KdcSocket(addr = options.listen, port = options.port)
    #kdcSocket.listen()
    #kdcSocket.loop(kdc_request_handler)

if __name__ == "__main__":
    main()

