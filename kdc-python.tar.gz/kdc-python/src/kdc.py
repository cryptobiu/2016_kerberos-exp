#!/usr/bin/python

from kdc_socket import KdcSocket
from kdc_request_handler import kdc_request_handler
from kdc_debug import *

def main():
    KdcDebug().setDebugLevel(8)
    kdcSocket = KdcSocket()
    kdcSocket.listen()
    kdcSocket.loop(kdc_request_handler)


if __name__ == "__main__":
    main()
