
import struct
from dateutil.relativedelta import relativedelta
import datetime

class KrbError(object):

    def __init__(self):
        self.m_pvno = 5
        self.m_magic = chr(0) + chr(0) + chr(0) + chr(0xbb) + chr(0x7e) + chr(0x81) + chr(0xb8) + chr(0x30) + chr(0x81) + chr(0xb5) + chr(0xa0) + chr(0x03) + chr(0x02) + chr(0x01)
        self.m_msg_type = 0
        self.m_ctime = 0  # Client sec portion; optional
        self.m_cusec = 0  # Client usec portion; optional
        self.m_susec = 0  # Server usec portion
        self.m_stime = 0  # Server sec portion
        self.m_error_code = 0 # Error code (protocol error #'s)
        self.m_crealm = 0 # Client principal and realm
        self.m_cname = 0 # 
        self.m_realm = 0 #  Server principal and realm
        self.m_sname = 0
        self.m_e_text = 0 # Descriptive text
        self.m_e_data = 0 # Additional error-describing data

        self.m_buffer = ""

    def _write_date_time(self, date):
        a = datetime.datetime.now().__format__("%Y%m%d%H%M%SZ")
        self.m_buffer = self.m_buffer + a


    def _write_offset(self, size = 4):
        s = 0
        while s < size:
            self.m_buffer.append(0x00)
            s = s + 1


    def _write_integer(self, number, size = 4):
        b = struct.pack('>I', number)
        if size < 4:
            b = b[4-size:]
        self.m_buffer = self.m_buffer + b


    def _write_string(self, bts):
        self.m_buffer = self.m_buffer + bts


    def _write_bytes(self, byts):
        self.m_buffer = self.m_buffer + str(byts)


class KrbErroNoEtype(KrbError):
    def __init__(self):
        KrbError.__init__(self)
        self.m_msg_type = 0x1e
        self.m_ctime = datetime.datetime.now()# + relativedelta(years=10)
        self.s_stime = datetime.datetime.now()
        self.m_susec = 730437 # What?
        self.m_error_code = 14
        self.m_crealm = "KRB.ZIMMERLE.ORG"
        self.m_name = "user"
        self.m_realm = "KRB.ZIMMERLE.ORG"
        self.m_name_type = 0x01 # what? 

    def byts(self):
        self.m_buffer = ""
        self._write_bytes(self.m_magic)
        self._write_integer(self.m_pvno, 1)
        self._write_bytes(chr(0xa1) + chr(0x03) + chr(0x02) + chr(0x01))
        self._write_integer(self.m_msg_type, 1)
        self._write_bytes(chr(0xA2) + chr(0x11) + chr(0x18) + chr(0x0F))
        self._write_date_time(self.m_ctime)
        self._write_bytes(chr(0xA4) + chr(0x11) + chr(0x18) + chr(0x0F))
        self._write_date_time(self.m_stime)
        # 05 02 03 0B
        self._write_bytes(chr(0xA5))
        self._write_bytes(chr(0x05) + chr(0x02) + chr(0x03))
        self._write_integer(self.m_susec, size = 3)
        self._write_bytes(chr(0xa6) + chr(0x03) + chr(0x02) + chr(0x01))
        self._write_integer(self.m_error_code, 1)
        self._write_bytes(chr(0xa7) + chr(0x12) + chr(0x1b) + chr(0x10))
        self._write_string(self.m_crealm)
        self._write_bytes(chr(0xa8) + chr(0x11))
        self._write_bytes(chr(0x30) + chr(0x0f) + chr(0xa0) + chr(0x03) + chr(0x02) + chr(0x01))
        self._write_integer(self.m_name_type, 1)
        self._write_bytes(chr(0xa1) + chr(0x08) + chr(0x30) + chr(0x06))
        self._write_bytes(chr(0x1b) + chr(0x04))
        self._write_string(self.m_name)
        self._write_bytes(chr(0xa9) + chr(0x12) + chr(0x1b) + chr(0x10))
        self._write_string(self.m_realm)
        self._write_bytes(chr(0xaa) + chr(0x25))
        self._write_bytes(chr(0x30) + chr(0x23) + chr(0xa0) + chr(0x03))
        self._write_bytes(chr(0x02) + chr(0x01))

        self._write_bytes(chr(0x02)) # Amount of strings?
        self._write_bytes(chr(0xa1) + chr(0x1c) + chr(0x30) + chr(0x1a))
        self._write_bytes(chr(0x1b) + chr(0x06))
        self._write_string("krbtgt")
        self._write_bytes(chr(0x1b) + chr(0x10))
        self._write_string(self.m_realm)

        self._write_bytes(chr(0xab) + chr(0x15) + chr(0x1b) + chr(0x13))
        self._write_string("BAD_ENCRYPTION_TYPE")

        return self.m_buffer

