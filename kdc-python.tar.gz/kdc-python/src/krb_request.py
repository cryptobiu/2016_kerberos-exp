

from kdc_debug import *
import struct
import datetime


"""
 Msgs types:
    krb-as-req - 10) -- Request for initial authentication
    krb-as-rep - 11) -- Response to KRB_AS_REQ request
    krb-tgs-req - 12 -- Request for authentication based on TGT
    krb-tgs-rep - 13 -- Response to KRB_TGS_REQ request
    krb-ap-req - 14 -- application request to server
    krb-ap-rep - 15 -- Response to KRB_AP_REQ_MUTUAL
    krb-safe - 20 -- Safe (checksummed) application message
    krb-priv - 21 -- Private (encrypted) application message
    krb-cred - 22 -- Private (encrypted) message to forward credentials
    krb-error - 30 -- Error response
"""

# http://www.ietf.org/rfc/rfc4120.txt

def krb_request_from_data(data):
    if len(data) < 21:
        kdcd(7, "Data is smaller than a regular krb message")
        return None

    typ = int(ord(data[19]))

    if typ == 0x0A:
        kdcd(7, "We have a krb-as-req message")
        return KrbRequestAsReq(data)
 
    return KrbRequest(data)


class KrbRequest(object):
    
    UNK_REQ = -1
    AS_REQ = 1

    def _read_string(self, offset = 0):
        self.m_offset = self.m_offset + offset
        string_size = ord(self.m_data[self.m_offset:self.m_offset + 1])
        self.m_offset = self.m_offset + 1
        string = self.m_data[self.m_offset:self.m_offset + string_size]
        self.m_offset = self.m_offset + string_size
        return string

    def _read_integer(self, offset = 0, size = 4):
        number = 0
        self.m_offset = self.m_offset + offset
        number = self.m_data[self.m_offset:self.m_offset + size]
        size_tmp = size
        while size_tmp < 4:
            number = chr(0x00) + number
            size_tmp = size_tmp + 1

        kdcd(7, "reading integer: (maybe 'padded' with zeros)")
        kdcdh(7, number)
        self.m_offset = self.m_offset + size
        number = struct.unpack('>I', number)[0]
        kdcd(7, "read: " + str(number))
        return number

    def _read_msg_type(self, offset = 0):
        self.m_offset = self.m_offset + offset
        tpe = ord(self.m_data[self.m_offset:self.m_offset + 1])
        self.m_offset = self.m_offset + 1
        return tpe

    def _read_bytes(self, offset = 0, size = 1):
        self.m_offset = self.m_offset + offset
        byts = self.m_data[self.m_offset:self.m_offset + size]
        self.m_offset = self.m_offset + size
        return byts

    def _read_date_time(self, offset = 0):
        byts = self._read_bytes(offset = offset, size = 15)
        d = datetime.datetime.strptime(byts, "%Y%m%d%H%M%SZ")
        return d

    def __init__(self, data):
        self.m_offset = 0
        self.m_data = data
        
        self.m_reserved = self._read_integer(size = 2)
        kdcd(7, "reserved: " + str(self.m_reserved))

        self.m_record_length = self._read_integer(size = 2)
        kdcd(7, "record length: " + str(self.m_record_length))

        # [0] 2 bytes that i don't know
        # [2] 3rd byte contains the size of the rest of the request.
        # [3] starts the as-req, but the next 7 bytes i don't know what it is.
        # [10] ...

        # pvno
        self.pvno = self._read_integer(size = 1, offset = 10)
        kdcd(7, "pvno: " + str(self.pvno));

        # [0] here we have 4 bytes that it is not clear what it is doing.
        # [4] ...

        # msg-type
        self.m_msg_type = self._read_msg_type(offset = 4)
        kdcd(7, "msg type: " + str(self.m_msg_type))

        # [0] More 4 bytes that i cannot account for.
        # [4] ...

        # sequence of pa-data
        self.m_padata = self._read_bytes(offset = 4, size = 12)

        kdcd(7, "data:");
        kdcdh(7, self.m_padata)

        self.m_type = KrbRequest.UNK_REQ

    @staticmethod
    def type2label(tpe):
        if tpe == KrbRequest.AS_REQ:
            return "krb-ar-req"

        return "Unknown type or broken message"


class KrbRequestAsReq(KrbRequest):
    def __init__(self, data):
        KrbRequest.__init__(self, data)
        self.m_type = KrbRequest.AS_REQ

        if self.m_record_length > 164:
            self.m_offset = self.m_offset + 2 # don't ask
        elif self.m_record_length > 161:
            self.m_offset = self.m_offset + 1 # don't ask
       

        # [0] Last read was sequence of pa-data, here goes 8 
        # [

        # req body > padding
        self.m_padding = self._read_integer(size = 1, offset = 8)
        kdcd(7, "padding: " + str(self.m_padding));

        # req body > options
        self.m_options = self._read_bytes(offset = 0, size = 4)
        kdcd(7, "options: ");
        kdcdh(7, self.m_options)

        # cname-type
        self.m_name_type = self._read_bytes(offset = 9, size = 1)
        kdcd(7, "name-type:");
        kdcdh(7, self.m_name_type)

        # string
        self.m_user_name = self._read_string(4)
        kdcd(7, "user name:");
        kdcdh(7, self.m_user_name)

        # realm
        self.m_realm = self._read_string(3)
        kdcd(7, "realm:");
        kdcdh(7, self.m_realm)

        # sname > name-type
        self.m_sname_type = self._read_bytes(offset = 9, size = 1)
        kdcd(7, "name-type:");
        kdcdh(7, str(self.m_sname_type))

        # name-string
        # 2 ? name_type ?
        self.m_sname_one = self._read_string(4)
        kdcd(7, "sname one: ");
        kdcdh(7, self.m_sname_one)

        self.m_sname_two = self._read_string(1)
        kdcd(7, "sname two: ");
        kdcdh(7, self.m_sname_two)

        # till
        self.m_till = self._read_date_time(offset = 4)
        kdcd(7, "till: " + str(self.m_till));

        # nonce
        self.m_nonce = self._read_integer(offset = 4, size = 4)
        kdcd(7, "nonce: " + str(self.m_nonce))

        # enc type
        self.m_enc_type = self._read_integer(offset = 6, size = 1)
        kdcd(7, "enc type: " + str(self.m_enc_type));



